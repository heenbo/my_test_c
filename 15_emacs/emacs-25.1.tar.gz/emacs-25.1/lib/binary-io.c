#include <config.h>
#define BINARY_IO_INLINE _GL_EXTERN_INLINE
#include "binary-io.h"
typedef int dummy;
